gline = [ ['Year','umich.edu','indiana.edu','cam.ac.uk','mac.com','uct.ac.za','berkeley.edu','unicon.net','gmail.com','ucdavis.edu','stanford.edu'],
['2005',57,12,7,12,14,12,6,10,11,4],
['2006',892,424,405,352,304,282,287,225,218,164]
];
